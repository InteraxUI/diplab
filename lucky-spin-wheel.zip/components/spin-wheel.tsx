"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

// Define the segments for the wheel
const segments = [
  { text: "اطلب بيتزا + شاي بـ ١٥ ريال", color: "#f1ba3b", textColor: "#000000" },
  { text: "اطلب فطائر + شاي بـ ١٥ ريال", color: "#de9c35", textColor: "#000000" },
  { text: "بوكس كوكيز + قهوة اليوم بـ ٢٥ ريال", color: "#f1ba3b", textColor: "#000000" },
  { text: "اطلب قهوتك والثانية خصم ٥٠٪", color: "#de9c35", textColor: "#000000" },
  { text: "حظك اللي قبلك سبقك", color: "#2d2b28", textColor: "#ffffff" },
]

export default function SpinWheel() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isSpinning, setIsSpinning] = useState(false)
  const [selectedSegment, setSelectedSegment] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [angle, setAngle] = useState(0)
  const [spinAngle, setSpinAngle] = useState(0)
  const animationRef = useRef<number | null>(null)

  // Draw the wheel on the canvas
  const drawWheel = (currentAngle: number) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set the center of the wheel
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(centerX, centerY) - 10

    // Draw the wheel segments
    const segmentAngle = (2 * Math.PI) / segments.length

    for (let i = 0; i < segments.length; i++) {
      const startAngle = currentAngle + i * segmentAngle
      const endAngle = startAngle + segmentAngle

      // Draw segment
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.closePath()
      ctx.fillStyle = segments[i].color
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw text
      ctx.save()
      ctx.translate(centerX, centerY)
      ctx.rotate(startAngle + segmentAngle / 2)
      ctx.textAlign = "right"
      ctx.textBaseline = "middle"
      ctx.font = "bold 14px Arial"
      ctx.fillStyle = segments[i].textColor

      // Adjust text position based on canvas size
      const textDistance = radius * 0.75
      ctx.fillText(segments[i].text, textDistance, 0)
      ctx.restore()
    }

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, 15, 0, 2 * Math.PI)
    ctx.fillStyle = "#ffffff"
    ctx.fill()
    ctx.strokeStyle = "#000000"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw pointer
    ctx.beginPath()
    ctx.moveTo(centerX + 30, centerY)
    ctx.lineTo(centerX + radius + 10, centerY)
    ctx.strokeStyle = "#ff0000"
    ctx.lineWidth = 4
    ctx.stroke()

    // Draw circle at pointer tip
    ctx.beginPath()
    ctx.arc(centerX + radius + 10, centerY, 5, 0, 2 * Math.PI)
    ctx.fillStyle = "#ff0000"
    ctx.fill()
  }

  // Spin the wheel
  const spinWheel = () => {
    if (isSpinning) return

    setIsSpinning(true)
    setSelectedSegment(null)
    setShowResult(false)

    // Generate random number of rotations (3-6 full rotations)
    const rotations = 3 + Math.random() * 3

    // Generate random end angle within the available segments
    const segmentAngle = (2 * Math.PI) / segments.length
    const randomSegment = Math.floor(Math.random() * segments.length)

    // Calculate the total spin angle
    const totalSpinAngle = rotations * 2 * Math.PI + randomSegment * segmentAngle
    setSpinAngle(totalSpinAngle)

    // Set the selected segment
    setSelectedSegment(segments.length - 1 - randomSegment)

    // Start the animation
    let start: number | null = null
    const duration = 5000 // 5 seconds

    const animate = (timestamp: number) => {
      if (!start) start = timestamp
      const elapsed = timestamp - start
      const progress = Math.min(elapsed / duration, 1)

      // Easing function for smooth deceleration
      const easeOut = (t: number) => 1 - Math.pow(1 - t, 3)
      const currentAngle = angle + totalSpinAngle * easeOut(progress)

      setAngle(currentAngle)

      if (progress < 1) {
        animationRef.current = requestAnimationFrame(animate)
      } else {
        setIsSpinning(false)
        setShowResult(true)
      }
    }

    animationRef.current = requestAnimationFrame(animate)
  }

  // Clean up animation on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  // Draw the wheel whenever the angle changes
  useEffect(() => {
    drawWheel(angle)
  }, [angle])

  // Initialize the wheel on component mount
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    const updateCanvasSize = () => {
      const size = Math.min(window.innerWidth - 40, 500)
      canvas.width = size
      canvas.height = size
      drawWheel(angle)
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => {
      window.removeEventListener("resize", updateCanvasSize)
    }
  }, [])

  return (
    <div className="flex flex-col items-center">
      <div className="relative cursor-pointer mb-6" onClick={!isSpinning ? spinWheel : undefined}>
        <canvas ref={canvasRef} className="rounded-full shadow-lg" width={400} height={400} />
        {!isSpinning && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white bg-opacity-70 rounded-full p-4 shadow-md">
              <p className="text-lg font-bold text-center">اضغط للدوران</p>
            </div>
          </div>
        )}
      </div>

      <Button onClick={spinWheel} disabled={isSpinning} className="px-8 py-6 text-lg">
        {isSpinning ? "جاري الدوران..." : "ادر العجلة"}
      </Button>

      <Dialog open={showResult} onOpenChange={setShowResult}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">النتيجة</DialogTitle>
          </DialogHeader>
          <DialogDescription className="text-center text-lg font-bold">
            {selectedSegment !== null && segments[selectedSegment].text}
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </div>
  )
}
