import SpinWheel from "@/components/spin-wheel"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gray-50">
      <h1 className="text-3xl font-bold mb-8 text-center">عجلة الحظ</h1>
      <SpinWheel />
    </main>
  )
}
